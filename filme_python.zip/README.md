
# API de Filmes - Modo Teste (Sem API Key)

Este projeto é uma versão **totalmente funcional em modo teste**, sem necessidade de chave OMDB.

## 🚀 Como rodar

1. Instale as dependências:
```bash
pip install -r requirements.txt
```

2. Execute o servidor:
```bash
uvicorn main:app --reload
```

3. Acesse no navegador:
```
http://127.0.0.1:8000/filme?titulo=Matrix
```

Você verá algo assim:
```json
{
  "titulo": "Matrix",
  "ano": "2024",
  "sinopse": "Esta é uma sinopse de teste gerada pelo modo simulado, sem acesso à API real."
}
```

## 📌 Observação
Este modo não consulta nenhuma API real — é ideal para testes ou ambiente offline.
