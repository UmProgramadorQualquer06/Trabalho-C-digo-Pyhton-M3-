
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

# Modelo de resposta
class Filme(BaseModel):
    titulo: str
    ano: str
    sinopse: str

@app.get("/filme", response_model=Filme)
def consultar_filme(titulo: str):
    # MODO TESTE (sem API real)
    # Respostas simuladas para qualquer título informado
    return Filme(
        titulo=titulo,
        ano="2024",
        sinopse="Esta é uma sinopse de teste gerada pelo modo simulado, sem acesso à API real."
    )
